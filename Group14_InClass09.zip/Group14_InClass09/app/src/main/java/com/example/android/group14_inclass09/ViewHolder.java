package com.example.android.group14_inclass09;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by jeremybohannon on 10/15/17.
 */
//Jeremy Bohannon Elizabeth Thompson
//InClass09
//viewholder.java
class ViewHolder {
    TextView name;
    TextView email;
    TextView phone;
    TextView department;
    ImageView avatar;
}
