package com.example.android.group14_inclass07;

import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

/**
 * Created by jeremybohannon on 10/15/17.
 */
//Jeremy Bohannon Elizabeth Thompson
//InClass07
//viewholder.java
class ViewHolder {
    TextView name;
    TextView email;
    TextView phone;
    TextView department;
    ImageView avatar;
}
