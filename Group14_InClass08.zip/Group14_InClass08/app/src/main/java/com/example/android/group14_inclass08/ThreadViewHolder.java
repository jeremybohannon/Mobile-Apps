package com.example.android.group14_inclass08;

import android.widget.ImageView;
import android.widget.TextView;
// Jeremy Bohannon Elizabeth Thompson
// In class 08
// threadviewholder.java
class ThreadViewHolder {
    TextView thread;
    ImageView delete;
}
