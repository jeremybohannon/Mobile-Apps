package com.example.android.group14_hw05;

import android.widget.ImageView;
import android.widget.TextView;
//Jeremy Bohannon Elizabeth Thompson
//Homework 5
// ViewHolder.java
class ViewHolder {
    TextView title;
    ImageView image;
}
